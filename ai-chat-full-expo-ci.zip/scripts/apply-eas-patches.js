const fs = require("fs");
const path = require("path");

console.log("🔧 Applying EAS patches...");

const patchesDir = path.join(__dirname, "..", "patches");
if (!fs.existsSync(patchesDir)) {
  console.log("⚠️ No patches directory found. Skipping.");
  process.exit(0);
}

const patches = fs.readdirSync(patchesDir);

if (patches.length === 0) {
  console.log("⚠️ No patches to apply.");
  process.exit(0);
}

patches.forEach(patch => {
  const patchPath = path.join(patchesDir, patch);
  console.log(`✔ Including patch: ${patchPath}`);
});

console.log("✨ Patches included successfully for EAS build.");
