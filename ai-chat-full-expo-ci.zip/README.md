# AI Chat Whitehat - Expo SDK 50 with CI/CD

This project is an Expo SDK 50 app configured for EAS builds and GitHub Actions CI/CD.

Files of interest:
- app.json, package.json, eas.json
- .github/workflows/eas-android-ci.yml
- scripts/apply-eas-patches.js
- patches/cacache-move-file.patch
- assets/icon.png

Quickstart:
1. Install dependencies: `npm install`
2. Set your backend URL in `config.js`
3. Start dev server: `npx expo start`
4. Build AAB: `eas build -p android --profile production`

CI:
- Set `EXPO_TOKEN` and `GOOGLE_SERVICE_ACCOUNT_JSON` in GitHub secrets.
- Push to `main` to trigger CI build & submit.
