import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, Alert } from 'react-native';
import { BASE_URL } from './config';

export default function App() {
  const [message, setMessage] = useState('');
  const [reply, setReply] = useState('');

  async function sendMessage() {
    if (!message.trim()) return Alert.alert('Please enter a message');
    try {
      const res = await fetch(`${BASE_URL}/api/v1/chat/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation_id: '00000000-0000-4000-8000-000000000000',
          content: message
        })
      });
      const txt = await res.text();
      let data;
      try { data = JSON.parse(txt); } catch (e) { data = { reply: txt }; }
      setReply(data.reply || txt);
    } catch (err) {
      setReply('Network error: ' + (err.message || err));
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>AI Chat Whitehat</Text>
      <TextInput style={styles.input} placeholder="Type message" value={message} onChangeText={setMessage} multiline />
      <Button title="Send" onPress={sendMessage} />
      <ScrollView style={styles.replyBox}>
        <Text style={styles.replyText}>{reply}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:20, paddingTop:60 },
  title: { fontSize:24, fontWeight:'700', marginBottom:12 },
  input: { borderWidth:1, padding:10, minHeight:80, marginBottom:12 },
  replyBox: { marginTop:16 },
  replyText: { fontSize:16 }
});
