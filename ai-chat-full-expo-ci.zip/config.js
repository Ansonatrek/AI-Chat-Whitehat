export const BASE_URL = "https://ai-chat-app.com";
