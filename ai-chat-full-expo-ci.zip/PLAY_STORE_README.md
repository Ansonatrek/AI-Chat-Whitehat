Play Store signing notes (EAS):

- EAS can manage Android keystores for you during build.
- To submit automatically, create a Google Play service account (release manager),
  generate a JSON key and add it to GitHub Secrets as GOOGLE_SERVICE_ACCOUNT_JSON.
- Add EXPO_TOKEN as a secret too.
